package com.example.multireaderwriter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchMultiReaderWriterApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBatchMultiReaderWriterApplication.class, args);
    }

}
