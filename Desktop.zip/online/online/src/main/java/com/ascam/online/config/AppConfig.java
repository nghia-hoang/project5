package com.ascam.online.config;

public class AppConfig {

}
