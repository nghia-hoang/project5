package com.ascam.online.dto.request;

public class UserRequest {

}
