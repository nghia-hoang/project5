package com.ascam.online.entity;

public class User {

}
