package com.ascam.online.service;

public interface UserService {

}
