package com.ascam.online.repository;

public class UserRepository {

}
