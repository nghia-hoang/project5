package com.ascam.online.config;

import org.springframework.stereotype.Component;

@Component
public class CognitoConnectionTroubleshooter {

	private static final String TEST_URL = "http://localhost:9229/health";

//    @PostConstruct
//    public void testCognitoLocalConnection() {
//        System.out.println("\n--- Bắt đầu kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---");
//		RestTemplate restTemplate = new RestTemplate();
//        try {
//            System.out.println("Đang cố gắng GET: " + TEST_URL);
//			HttpHeaders headers = new HttpHeaders();
//			headers.setContentType(MediaType.valueOf("application/x-amz-json-1.1"));
//			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN, MediaType.ALL));
//			HttpEntity<String> entity = new HttpEntity<>(headers);
//			ResponseEntity<String> response = restTemplate.exchange(TEST_URL, HttpMethod.GET, entity, String.class);
//			System.out.println("Kiểm tra kết nối thành công! Phản hồi từ Cognito Local:\n"
//					+ response.getBody().substring(0, Math.min(response.getBody().length(), 500)) + "...");
//        } catch (ResourceAccessException e) {
//            System.err.println("LỖI KẾT NỐI TỪ SPRING BOOT (ResourceAccessException): " + e.getMessage());
//            System.err.println("Đây là lỗi bạn đang gặp. Vấn đề nằm ở việc ứng dụng Java không thể thiết lập kết nối mạng.");
//			e.printStackTrace(System.err);
//        } catch (Exception e) {
//            System.err.println("LỖI KHÁC TỪ SPRING BOOT: " + e.getMessage());
//            e.printStackTrace(System.err);
//        }
//		System.out.println("--- Kết thúc kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---\n");
//    }
}