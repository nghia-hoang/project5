package com.ascam.online.services.impl;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.ascam.online.entity.Order;
import com.ascam.online.repository.OrderRepository;
import com.ascam.online.service.OrderService;

@Service
public class OrderServiceIml implements OrderService {

	@Autowired
	OrderRepository orderRepository;


	@Override
	@Transactional(isolation = Isolation.REPEATABLE_READ, rollbackFor = Exception.class) // Ensures atomicity for the
																							// entire method
	public Order addItemsToExistingOrder(Long orderId, String newItemName, int newItemQuantity, double newItemPrice)
			throws IOException {
		// 1. Read the Order and acquire a PESSIMISTIC_WRITE lock
		// The findById method in OrderRepository is already annotated with
		// @Lock(LockModeType.PESSIMISTIC_WRITE)
		Optional<Order> optionalOrder = orderRepository.findById(orderId);

		Order order;
		if (optionalOrder.isPresent()) {
			order = optionalOrder.get();
		} else {
			// Tạo mới và lưu ngay vào database
			order = new Order();
			order.setCustomerName("Default Customer");
			order.setTotalAmount(0.0);
			order = orderRepository.save(order); // Lưu mới ngay lập tức

			// KHÔNG set ID thủ công!
			System.out.println("Created new order with ID: " + order.getId());
		}

		// Cập nhật thông tin
		order.setCustomerName("a4");
		order.setTotalAmount(21.4);
		if (1 == 1) {
			throw new IOException("File path cannot be null or empty.");
		}
		// Thêm item logic ở đây...

		return order;
	}
}
