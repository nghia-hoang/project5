package com.ascam.online.common.constants;

public class AppConstants {

}
