package com.ascam.online.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;

import com.ascam.online.entity.Order;

import jakarta.persistence.LockModeType;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

 @Override
@Lock(LockModeType.PESSIMISTIC_WRITE) // This is the key for row-level locking
 Optional<com.ascam.online.entity.Order> findById(Long id);
}

