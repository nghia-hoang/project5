package com.ascam.online.common.validation;

public class ValidatorMessages {

}
