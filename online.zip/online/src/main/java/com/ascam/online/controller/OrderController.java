package com.ascam.online.controller;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ascam.online.OnlineApplication;
import com.ascam.online.entity.Order;
import com.ascam.online.service.OrderService;
import com.ascam.online.services.impl.OrderServiceIml;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

	private final OrderServiceIml orderServiceIml;

	private final OnlineApplication onlineApplication;

	private final OrderService orderService;

	public OrderController(OrderService orderService, OnlineApplication onlineApplication,
			OrderServiceIml orderServiceIml) {
		this.orderService = orderService;
		this.onlineApplication = onlineApplication;
		this.orderServiceIml = orderServiceIml;
	}

	@PostMapping("/{orderId}/add-items")
	public ResponseEntity<Order> addItemsToOrder(@PathVariable Long orderId, @RequestParam String itemName,
			@RequestParam int quantity, @RequestParam double price) throws IOException {
		try {
			System.out.println("1");
			Order updatedOrder = orderService.addItemsToExistingOrder(orderId, itemName, quantity, price);
			System.out.println(updatedOrder.toString());
			return ResponseEntity.ok(updatedOrder);
		} catch (RuntimeException e) {
			return ResponseEntity.badRequest().body(null); // Or a more specific error response
		}
	}
}