package com.ascam.online.service;

import java.io.IOException;

import com.ascam.online.entity.Order;

public interface OrderService {
	Order addItemsToExistingOrder(Long orderId, String newItemName, int newItemQuantity, double newItemPrice)
			throws IOException;
}
