package com.ascam.online.dto.response;

public class UserResponse {

}
