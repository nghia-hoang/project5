package com.ascam.online.common.exception;

public class AppException {

}
