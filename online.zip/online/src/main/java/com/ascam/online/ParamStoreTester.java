package com.ascam.online;

public class ParamStoreTester {
//	public static void main(String[] args) {
//		SsmClient client = SsmClient.builder().region(Region.US_EAST_1).build();
//
//		GetParametersByPathRequest request = GetParametersByPathRequest.builder().path("/ASC").build();
//
//		client.getParametersByPath(request).parameters()
//				.forEach(param -> System.out.println(param.name() + " = " + param.value()));
//	}
}
