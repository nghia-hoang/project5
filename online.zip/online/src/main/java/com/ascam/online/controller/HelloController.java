package com.ascam.online.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@GetMapping("/hello")
	@PreAuthorize("hasRole('ROLE_USER')") // Ví dụ về ủy quyền dựa trên vai trò
	public String hello(@AuthenticationPrincipal Jwt jwt) {
		return "Hello, " + jwt.getClaimAsString("username") + "! Your token was issued by: "
				+ jwt.getIssuer().toString();
	}

	@GetMapping("/public/message")
	public String publicMessage() {
		return "This is a public message.";
	}
}
