package com.ascam.online.controller;

import java.net.URI;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.cognitoidentityprovider.CognitoIdentityProviderClient;
import software.amazon.awssdk.services.cognitoidentityprovider.model.InitiateAuthRequest;
import software.amazon.awssdk.services.cognitoidentityprovider.model.InitiateAuthResponse;

@RestController
public class HelloController {
	@Value("${ff}")
	private String message;

	@GetMapping("/hello")
//	@PreAuthorize("hasRole('ROLE_USER')") // Ví dụ về ủy quyền dựa trên vai trò
	public String hello(@AuthenticationPrincipal Jwt jwt) {
		return "Hello, " + message;
	}

	@GetMapping("/public/message")
	public String publicMessage() {
		return "This is a public message.";
	}

//	private static final String TEST_URL = "http://localhost:9229/health";
	private static final String TEST_URL = "http://127.0.0.1:9229";

	@GetMapping("/public/tets")
//	 public String testCognitoLocalConnection() {
//	        System.out.println("\n--- Bắt đầu kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---");
//			RestTemplate restTemplate = new RestTemplate();
//	        try {
//	            System.out.println("Đang cố gắng GET: " + TEST_URL);
//				HttpHeaders headers = new HttpHeaders();
//				headers.setContentType(MediaType.valueOf("application/x-amz-json-1.1"));
//				headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN, MediaType.ALL));
//				HttpEntity<String> entity = new HttpEntity<>(headers);
//				ResponseEntity<String> response = restTemplate.exchange(TEST_URL, HttpMethod.GET, entity, String.class);
//				System.out.println("Kiểm tra kết nối thành công! Phản hồi từ Cognito Local:\n"
//						+ response.getBody().substring(0, Math.min(response.getBody().length(), 500)) + "...");
//	        } catch (ResourceAccessException e) {
//	            System.err.println("LỖI KẾT NỐI TỪ SPRING BOOT (ResourceAccessException): " + e.getMessage());
//	            System.err.println("Đây là lỗi bạn đang gặp. Vấn đề nằm ở việc ứng dụng Java không thể thiết lập kết nối mạng.");
//				e.printStackTrace(System.err);
//	        } catch (Exception e) {
//	            System.err.println("LỖI KHÁC TỪ SPRING BOOT: " + e.getMessage());
//	            e.printStackTrace(System.err);
//	        }
//			System.out.println("--- Kết thúc kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---\n");
//			return "test";
//	    }
	public void testCognitoLocalConnection() {
		System.out.println("\n--- Bắt đầu kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---");
		try {
			// Configure Cognito client
			AwsBasicCredentials credentials = AwsBasicCredentials.create("test", "test");
			CognitoIdentityProviderClient client = CognitoIdentityProviderClient.builder().region(Region.US_EAST_1)
					.endpointOverride(URI.create("http://localhost:9229"))
					.credentialsProvider(StaticCredentialsProvider.create(credentials)).build();

			// Build InitiateAuth request
			InitiateAuthRequest request = InitiateAuthRequest.builder().authFlow("USER_PASSWORD_AUTH")
					.clientId("870jc0qg77j04m447twgo9b9z").authParameters(new HashMap<>() {
						{
							put("USERNAME", "nghia@gmail.com");
							put("PASSWORD", "123");
						}
					}).build();

			// Send request
			InitiateAuthResponse response = client.initiateAuth(request);
			System.out.println("Kiểm tra kết nối thành công! Access Token:\n"
					+ response.authenticationResult().accessToken().substring(0, 50) + "...");

		} catch (Exception e) {
			System.err.println("LỖI KẾT NỐI TỪ SPRING BOOT: " + e.getMessage());
			e.printStackTrace(System.err);
		}
		System.out.println("--- Kết thúc kiểm tra kết nối tới Cognito Local từ ứng dụng Spring Boot ---\n");
	}
}
