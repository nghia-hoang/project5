import json

def lambda_handler(event, context):
    data_list = event
    validated_list = []
    for data in data_list:
        if not data.get('id') or not data.get('value'):
            raise ValueError(f"Invalid data: id and value are required for item {data}")
        if not data['value'].isalnum():
            raise ValueError(f"Invalid data: value must be alphanumeric for item {data}")
        validated_list.append(data)
    return validated_list