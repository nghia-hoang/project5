package com.example.step2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
public class Step2Application {
    public static void main(String[] args) {
        SpringApplication.run(Step2Application.class, args);
    }
}

@RestController
class Step2Controller {
    @PostMapping("/process")
    public String processData(@RequestBody List<ValidatedData> dataList) {
        StringBuilder result = new StringBuilder();
        for (ValidatedData data : dataList) {
            result.append("Processed data with ID: ").append(data.getId())
                  .append(", Value: ").append(data.getValue()).append("\n");
        }
        return result.toString();
    }
}

class ValidatedData {
    private String id;
    private String value;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
}