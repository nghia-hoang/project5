package com.example.step1;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class Step1Application {
    public static void main(String[] args) {
        SpringApplication.run(Step1Application.class, args);
    }
}

@RestController
class Step1Controller {
    private final AmazonS3 s3Client = AmazonS3ClientBuilder.standard().build();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostMapping("/process")
    public List<InputData> processCsv(@RequestBody S3Input s3Input) throws Exception {
        List<InputData> dataList = new ArrayList<>();
        S3Object s3Object = s3Client.getObject(s3Input.getBucket(), s3Input.getKey());
        try (S3ObjectInputStream inputStream = s3Object.getObjectContent();
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine) {
                    firstLine = false;
                    continue; // Bỏ qua header
                }
                String[] parts = line.split(",");
                InputData data = new InputData();
                data.setId(parts[0]);
                data.setValue(parts[1]);
                dataList.add(data);
            }
        }
        return dataList;
    }
}

class S3Input {
    private String bucket;
    private String key;

    public String getBucket() { return bucket; }
    public void setBucket(String bucket) { this.bucket = bucket; }
    public String getKey() { return key; }
    public void setKey(String key) { this.key = key; }
}

class InputData {
    private String id;
    private String value;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getValue() { return value; }
    public void setValue(String value) { this.value = value; }
}