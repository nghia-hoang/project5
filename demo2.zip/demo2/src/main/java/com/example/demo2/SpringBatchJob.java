package com.example.demo2;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class SpringBatchJob {

    @Bean
	public Job delayedMessageJob(JobRepository jobRepository, Step step1, JobExecutionListener listener) {
		return new JobBuilder("delayedMessageJob", jobRepository).incrementer(new RunIdIncrementer()).listener(listener)
				.flow(step1).end()
                .build();
    }

    @Bean
	public Step step1(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
		return new StepBuilder("step1", jobRepository).tasklet((contribution, chunkContext) -> {
			System.out.println("Processing batch job with a 10-minute delay...");

			// Wait for 10 minutes (600,000 milliseconds)
			try {
				Thread.sleep(600000);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new RuntimeException("Job was interrupted", e);
			}

			System.out.println("Batch job completed after waiting 1! ");
			return RepeatStatus.FINISHED;
		}, transactionManager)
                .build();
    }
}